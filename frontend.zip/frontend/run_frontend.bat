@echo off
title VeriNews AI - Frontend (React + Vite)
cd /d "%~dp0"

echo ========================================================
echo   Starting VeriNews AI 2.0 Frontend (Vite)
echo ========================================================
echo.

where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js is not found in PATH!
    echo Please install Node.js from https://nodejs.org/ (Download LTS).
    echo After installing, close and reopen this script.
    echo.
    pause
    exit /b 1
)

if not exist "node_modules" (
    echo Installing npm packages (first time run)...
    call npm install
    if errorlevel 1 (
        echo [ERROR] npm install failed.
        pause
        exit /b 1
    )
)

echo Starting Vite development server...
echo.
call npm run dev

echo.
pause
