import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  RefreshCw,
  Menu,
  X,
  Layers,
  ChevronRight,
  Database,
  Award,
  ShieldAlert,
  GitMerge,
  Cpu,
  GraduationCap,
  TrendingUp,
  AlertTriangle,
  Sparkles,
  Info
} from 'lucide-react';
import { api } from '../services/api';

// Subcomponents
import { DashboardSidebar, DASHBOARD_SECTIONS } from '../components/dashboard/DashboardSidebar';
import { OverviewSection } from '../components/dashboard/OverviewSection';
import { MLPerformanceSection } from '../components/dashboard/MLPerformanceSection';
import { HybridEnsembleSection } from '../components/dashboard/HybridEnsembleSection';
import { DatasetAnalyticsSection } from '../components/dashboard/DatasetAnalyticsSection';
import { BiasAnalysisSection } from '../components/dashboard/BiasAnalysisSection';
import { TrainingEvaluationSection } from '../components/dashboard/TrainingEvaluationSection';
import { DetectionTrendsSection } from '../components/dashboard/DetectionTrendsSection';
import { ArchitectureTimelineSection } from '../components/dashboard/ArchitectureTimelineSection';
import { ApplicationModulesSection } from '../components/dashboard/ApplicationModulesSection';
import { LimitationsScopeSection } from '../components/dashboard/LimitationsScopeSection';

export const DashboardPage = ({ setActivePage }) => {
  const [activeSection, setActiveSection] = useState('overview');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [analyticsData, setAnalyticsData] = useState(null);
  const [viewMode, setViewMode] = useState('section'); // 'section' or 'all'

  // Fetch complete analytics bundle
  const loadData = async (isManualRefresh = false) => {
    if (isManualRefresh) setRefreshing(true);
    else setLoading(true);

    try {
      const data = await api.getFullAnalytics();
      setAnalyticsData(data);
    } catch (err) {
      console.warn("Failed to fetch full analytics data:", err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleNavigateSection = (sectionId) => {
    setActiveSection(sectionId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigatePage = (pageId) => {
    if (setActivePage) {
      setActivePage(pageId);
    }
  };

  const currentSectionMeta = DASHBOARD_SECTIONS.find(s => s.id === activeSection) || DASHBOARD_SECTIONS[0];

  return (
    <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Top Header & Telemetry Sync Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5 mb-6">
        <div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
              title="Open Navigation Drawer"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                <span>VeriNews AI 2.0 Research & Telemetry Hub</span>
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                ISOT Benchmark Analytics, Model Comparisons, Hard Majority Voting, and Bias Audits.
              </p>
            </div>
          </div>
        </div>

        {/* Right Controls */}
        <div className="flex items-center gap-2.5 self-end sm:self-center">
          {/* View Mode Toggle */}
          <div className="p-1 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center text-xs">
            <button
              onClick={() => setViewMode('section')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                viewMode === 'section'
                  ? 'bg-cyan-600/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Focused View
            </button>
            <button
              onClick={() => setViewMode('all')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                viewMode === 'all'
                  ? 'bg-cyan-600/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Full Report
            </button>
          </div>

          <button
            onClick={() => loadData(true)}
            disabled={refreshing}
            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 flex items-center gap-1.5 transition-all disabled:opacity-50"
            title="Refresh Real-Time Telemetry"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-cyan-400' : ''}`} />
            <span className="hidden sm:inline">{refreshing ? 'Syncing...' : 'Sync Telemetry'}</span>
          </button>
        </div>
      </div>

      {/* Main Layout: Sidebar Navigation + Content Area */}
      <div className="flex items-start gap-8">
        
        {/* Left Sticky Sidebar */}
        <DashboardSidebar
          activeSection={activeSection}
          setActiveSection={setActiveSection}
          isMobileOpen={isMobileSidebarOpen}
          setIsMobileOpen={setIsMobileSidebarOpen}
        />

        {/* Right Content Area */}
        <main className="flex-1 min-w-0 space-y-12">
          
          {loading ? (
            /* Loading Skeleton State */
            <div className="space-y-6 animate-pulse">
              <div className="h-20 rounded-2xl bg-slate-900/80 border border-slate-800" />
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
                  <div key={i} className="h-32 rounded-2xl bg-slate-900/80 border border-slate-800" />
                ))}
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="h-72 rounded-2xl bg-slate-900/80 border border-slate-800" />
                <div className="h-72 rounded-2xl bg-slate-900/80 border border-slate-800" />
              </div>
            </div>
          ) : viewMode === 'section' ? (
            /* Focused View (Single Active Section) */
            <div>
              {activeSection === 'overview' && (
                <OverviewSection
                  overviewData={analyticsData?.overview}
                  isDemo={analyticsData?.overview?.is_demo_telemetry}
                  onNavigateSection={handleNavigateSection}
                />
              )}

              {activeSection === 'ml-performance' && (
                <MLPerformanceSection
                  researchResults={analyticsData?.research_results}
                  confusionMatrix={analyticsData?.benchmark_confusion_matrix}
                />
              )}

              {activeSection === 'hybrid-ensemble' && (
                <HybridEnsembleSection />
              )}

              {activeSection === 'dataset-analytics' && (
                <DatasetAnalyticsSection
                  datasetData={analyticsData?.dataset_analytics}
                />
              )}

              {activeSection === 'bias-validation' && (
                <BiasAnalysisSection
                  experimentsData={analyticsData?.validation_experiments}
                />
              )}

              {activeSection === 'training-testing' && (
                <TrainingEvaluationSection
                  modelBenchmark={analyticsData?.benchmark_confusion_matrix ? {
                    testing_accuracy: 99.2,
                    testing_precision: 99.1,
                    testing_recall: 99.3,
                    testing_f1: 99.2,
                    training_accuracy: null,
                    confusion_matrix: analyticsData.benchmark_confusion_matrix
                  } : null}
                />
              )}

              {activeSection === 'detection-trends' && (
                <DetectionTrendsSection
                  detectionData={analyticsData?.detection_trends}
                  isDemo={analyticsData?.overview?.is_demo_telemetry}
                />
              )}

              {activeSection === 'architecture-timeline' && (
                <ArchitectureTimelineSection
                  onNavigateSection={handleNavigateSection}
                />
              )}

              {activeSection === 'application-modules' && (
                <ApplicationModulesSection
                  modulesList={analyticsData?.application_modules}
                  totalScans={analyticsData?.overview?.kpi?.total_news_scans ?? 0}
                  onNavigatePage={handleNavigatePage}
                />
              )}

              {activeSection === 'limitations-scope' && (
                <LimitationsScopeSection />
              )}
            </div>
          ) : (
            /* Full Report View (All Sections Sequentially) */
            <div className="space-y-16">
              <section id="overview" className="scroll-mt-20">
                <OverviewSection
                  overviewData={analyticsData?.overview}
                  isDemo={analyticsData?.overview?.is_demo_telemetry}
                  onNavigateSection={handleNavigateSection}
                />
              </section>

              <section id="ml-performance" className="scroll-mt-20">
                <MLPerformanceSection
                  researchResults={analyticsData?.research_results}
                  confusionMatrix={analyticsData?.benchmark_confusion_matrix}
                />
              </section>

              <section id="hybrid-ensemble" className="scroll-mt-20">
                <HybridEnsembleSection />
              </section>

              <section id="dataset-analytics" className="scroll-mt-20">
                <DatasetAnalyticsSection
                  datasetData={analyticsData?.dataset_analytics}
                />
              </section>

              <section id="bias-validation" className="scroll-mt-20">
                <BiasAnalysisSection
                  experimentsData={analyticsData?.validation_experiments}
                />
              </section>

              <section id="training-testing" className="scroll-mt-20">
                <TrainingEvaluationSection
                  modelBenchmark={analyticsData?.benchmark_confusion_matrix ? {
                    testing_accuracy: 99.2,
                    testing_precision: 99.1,
                    testing_recall: 99.3,
                    testing_f1: 99.2,
                    training_accuracy: null,
                    confusion_matrix: analyticsData.benchmark_confusion_matrix
                  } : null}
                />
              </section>

              <section id="detection-trends" className="scroll-mt-20">
                <DetectionTrendsSection
                  detectionData={analyticsData?.detection_trends}
                  isDemo={analyticsData?.overview?.is_demo_telemetry}
                />
              </section>

              <section id="architecture-timeline" className="scroll-mt-20">
                <ArchitectureTimelineSection
                  onNavigateSection={handleNavigateSection}
                />
              </section>

              <section id="application-modules" className="scroll-mt-20">
                <ApplicationModulesSection
                  modulesList={analyticsData?.application_modules}
                  totalScans={analyticsData?.overview?.kpi?.total_news_scans ?? 0}
                  onNavigatePage={handleNavigatePage}
                />
              </section>

              <section id="limitations-scope" className="scroll-mt-20">
                <LimitationsScopeSection />
              </section>
            </div>
          )}

          {/* Quick Navigation Footer */}
          <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <p>VeriNews AI 2.0 • Academic Research & Analytics Portal</p>
            <div className="flex items-center gap-4">
              <button
                onClick={() => handleNavigatePage('scanner')}
                className="hover:text-cyan-400 transition-colors"
              >
                Launch Scanner
              </button>
              <span>•</span>
              <button
                onClick={() => handleNavigatePage('claims')}
                className="hover:text-cyan-400 transition-colors"
              >
                Claim Intel
              </button>
              <span>•</span>
              <button
                onClick={() => handleNavigatePage('model')}
                className="hover:text-cyan-400 transition-colors"
              >
                Model Studio
              </button>
              <span>•</span>
              <button
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="text-cyan-400 hover:text-cyan-300 font-bold"
              >
                ↑ Back to Top
              </button>
            </div>
          </div>

        </main>
      </div>

    </div>
  );
};
